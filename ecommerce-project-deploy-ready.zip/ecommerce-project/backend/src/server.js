import 'dotenv/config';import express from 'express';import cors from 'cors';import path from 'path';import {fileURLToPath} from 'url';import {connectDB} from './config/db.js';import auth from './routes/auth.js';import products from './routes/products.js';import orders from './routes/orders.js';
const app=express();app.use(cors());app.use(express.json());
app.get('/api/health',(req,res)=>res.json({status:'ok',service:'E-Commerce API'}));app.use('/api/auth',auth);app.use('/api/products',products);app.use('/api/orders',orders);
const __dirname=path.dirname(fileURLToPath(import.meta.url));app.use(express.static(path.join(__dirname,'../../frontend')));app.get('/{*splat}',(req,res)=>res.sendFile(path.join(__dirname,'../../frontend/index.html')));
const port=process.env.PORT||5000;connectDB().then(()=>app.listen(port,()=>console.log(`Server running at http://localhost:${port}`))).catch(e=>{console.error(e);process.exit(1)});
