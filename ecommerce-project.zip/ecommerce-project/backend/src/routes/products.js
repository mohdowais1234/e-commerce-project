import {Router} from 'express';import Product from '../models/Product.js';import {protect,adminOnly} from '../middleware/auth.js';
const r=Router();
r.get('/',async(req,res)=>{try{const q={};if(req.query.category)q.category=req.query.category;if(req.query.search)q.name={$regex:req.query.search,$options:'i'};res.json(await Product.find(q).sort({createdAt:-1}))}catch(e){res.status(500).json({message:e.message})}});
r.get('/:id',async(req,res)=>{try{const p=await Product.findById(req.params.id);if(!p)return res.status(404).json({message:'Product not found'});res.json(p)}catch(e){res.status(500).json({message:e.message})}});
r.post('/',protect,adminOnly,async(req,res)=>{try{res.status(201).json(await Product.create(req.body))}catch(e){res.status(400).json({message:e.message})}});
r.put('/:id',protect,adminOnly,async(req,res)=>{try{const p=await Product.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});res.json(p)}catch(e){res.status(400).json({message:e.message})}});
r.delete('/:id',protect,adminOnly,async(req,res)=>{try{await Product.findByIdAndDelete(req.params.id);res.json({message:'Product deleted'})}catch(e){res.status(500).json({message:e.message})}});export default r;
