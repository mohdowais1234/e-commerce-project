# E-Commerce and Digital Marketing Project

Full-stack e-commerce project using HTML5, CSS3, JavaScript, TypeScript-ready frontend structure, Node.js, Express.js and MongoDB.

## Features
- Product listing, search and category filtering
- Product details
- Shopping cart with localStorage
- User registration/login using JWT
- Secure password hashing with bcrypt
- Checkout and order creation
- Stock validation and automatic stock reduction
- User order history
- Admin-ready product and order APIs
- Responsive UI

## Run
1. Install Node.js and MongoDB.
2. Copy `backend/.env.example` to `backend/.env` and edit values.
3. Run `npm install --prefix backend`.
4. Run `npm start --prefix backend`.
5. Open `http://localhost:5000`.

## Create an admin
Register a normal user, then in MongoDB set its `role` field to `admin`. Admin APIs are protected by JWT.

## API endpoints
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`
- GET `/api/products`
- GET `/api/products/:id`
- POST/PUT/DELETE `/api/products` (admin)
- POST `/api/orders`
- GET `/api/orders/mine`
- GET `/api/orders` (admin)
- PUT `/api/orders/:id/status` (admin)
